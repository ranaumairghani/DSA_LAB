#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    int i,*x;
    x=&i;

    for(*x=2; *x<=10; *x=*x+2)
    {
        cout<<*x<<" ";
    }
    return 0;
}
