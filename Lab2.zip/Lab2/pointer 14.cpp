#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    int *ptr;
    ptr=new int;
    return 0;
}
