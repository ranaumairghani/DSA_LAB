#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    int p,r,t,si,*pr,*rt,*tm,*sint;
    pr=&p;
    rt=&r;
    tm=&t;
    sint=&si;

    cout<<"Enter Principal: ";
    cin>>*pr;
    cout<<"Enter Rate: ";
    cin>>*rt;
    cout<<"Enter Time: ";
    cin>>*tm;

    *sint=(*pr * *rt * *tm)/100;
    cout<<"Simple Interest = "<<*sint;
    return 0;
}
