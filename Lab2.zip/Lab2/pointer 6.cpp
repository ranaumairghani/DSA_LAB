#include <iostream>
#include <conio.h>
using namespace std;
int main()
{
    int num1=300,num2=15,div;
//integr variable declaration
    int *ptr1,*ptr2;
//pointer variable declaration
    ptr1=&num1;
 //Assign the address of num1 to pointer variable ptr1
    ptr2=&num2;
 //Assign the address of num2 to pointer variable ptr2
    div=*ptr1/ *ptr2;
//find division of two numbers using pointer
    cout<<"Division is: "<<div;
//Display result on the screen
    getch();
    return 0;
}
