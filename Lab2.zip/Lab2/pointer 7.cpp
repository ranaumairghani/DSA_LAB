#include <iostream>
#include <conio.h>
using namespace std;
int main()
{
    int num1,num2,div;//integer variable declaration
    int *ptr1,*ptr2;//pointer variable declaration
cout<<"Enter first number: ";
//Ask input from the user
cin>>num1;//Reading the input from the user for num1
cout<<"Enter second number: ";//Ask input from the user
cin>>num2;//Reading the input from the user for num2
    ptr1=&num1;
    //Assign the address of num1 to pointer variable ptr1
    ptr2=&num2;
    //Assign the address of num2 to pointer variable ptr2
    div=*ptr1/ *ptr2;
    //Divide two numbers using pointer variable
    cout<<"Division is: "<<div;
    //Display result on the screen
    getch();
    return 0;
}
