#include <iostream>
#include <conio.h>
using namespace std;
int main()
{
    int num1,num2;      //1
    int *ptr1,*ptr2;    //2
    int sub;              //3
    cout<<"Please enter value for num1: ";    //4
    cin>>num1;                           //5
    cout<<"Please enter value for num2: ";    //4
    cin>>num2;                           //7
    ptr1=&num1;                                      //8
    ptr2=&num2;
    sub=*ptr1 - *ptr2;                                 //10
    cout<<"Product of the two integer values is: "<<sub;  //11
    getch();
    return 0;
}
